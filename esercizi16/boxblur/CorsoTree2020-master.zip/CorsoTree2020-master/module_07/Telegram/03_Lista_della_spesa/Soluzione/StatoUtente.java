package botspesa;

public enum StatoUtente {
    NORMALE,RIMUOVIPRODOTTO,AGGIUNGIPRODOTTO;
}
