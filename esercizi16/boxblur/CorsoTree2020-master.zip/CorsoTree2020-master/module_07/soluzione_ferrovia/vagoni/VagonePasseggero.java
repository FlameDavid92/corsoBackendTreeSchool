package vagoni;

public class VagonePasseggero extends Vagone {

    public VagonePasseggero(int id, int capienza) {
        super(id, capienza);
    }

}
