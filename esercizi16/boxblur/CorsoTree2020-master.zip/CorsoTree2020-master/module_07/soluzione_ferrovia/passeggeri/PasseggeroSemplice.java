package passeggeri;

public class PasseggeroSemplice extends Passeggero{

    public PasseggeroSemplice(String nome, String codiceBiglietto, int idVagone, int idStazioneArrivo) {
        super(nome, codiceBiglietto, idVagone, idStazioneArrivo);
    }

}
