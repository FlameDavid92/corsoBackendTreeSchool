## Iterabile 🛴 

Progettare un'interfaccia Iterabile che permette di fare le seguenti operazioni
* Object next()         che permette di ottenere il prossimo elemento 
* boolean hasNext()     che indica se è presente un prossimo elemento nella sequenza
* void reset()          che fa resetta l'iterazione

Progettare due classi ListaDiInteri, costruita con un array di interi, e MiaStringa, costruita con una stringa, che usano l'interfaccia Iterabile e ne implementano i metodi
(Considerare una stringa come una sequenza di char)

Usare il codice di test per verificare le funzioni