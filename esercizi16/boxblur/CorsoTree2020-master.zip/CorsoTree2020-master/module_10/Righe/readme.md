## Collection di righe 🛴

Leggere il file righe.txt usando le classi del package java.nio

Aggiungere le righe in una collection

Scrivere le righe nel file righeInverse.txt in ordine inverso, quindi l'ultima riga del file righe.txt deve essere la prima riga del file righeInverse.txt