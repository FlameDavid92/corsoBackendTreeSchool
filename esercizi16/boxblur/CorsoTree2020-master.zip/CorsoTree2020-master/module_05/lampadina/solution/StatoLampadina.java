package com.company;

public enum StatoLampadina {
    ACCESA, SPENTA, ROTTA
}
