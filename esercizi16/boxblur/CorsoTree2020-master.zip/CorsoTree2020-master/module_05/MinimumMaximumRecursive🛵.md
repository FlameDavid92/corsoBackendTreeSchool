Esercizio Minimo e Massimo Ricorsivo 🛵

Scrivere una funzione ricorsiva che, dato un array a non ordinato di interi positivi e 
negativi, trovi e stampi il minimo elemento e il massimo elemento dell'array a.

Esempio:
array: [40, 90, 130] 
minMaxRecursive(array) deve stampare 40 e 130


