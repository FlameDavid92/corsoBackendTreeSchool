public enum SituazioneClinica {
    SOTTOCONTROLLO, CAUTELA, CRITICA;
}
