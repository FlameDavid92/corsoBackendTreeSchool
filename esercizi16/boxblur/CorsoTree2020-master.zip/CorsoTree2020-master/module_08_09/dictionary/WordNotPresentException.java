package module_08_09.dictionary;

public class WordNotPresentException extends Exception{
}
