package module_08_09.dictionary;

public class LetterNotPresentException extends Exception{
}
