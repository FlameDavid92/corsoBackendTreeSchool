Esercizio Forme Geometriche 🛴 

Scrivere un programma in grado di modellare il concetto di forma geometrica
 associato a quadrati e rettangoli. In particolare, create le classi 
 Quadrato e Rettangolo entrambe con le seguenti caratteristiche:
Ogni Quadrato deve esporre 3 metodi:
- getArea: ritorna un intero
- getPerimeter: ritorna il perimetro dell’oggetto
- toString: ritorna «quadrato» o «rettangolo» a seconda del tipo di oggetto

Deve essere possibile eseguire il seguente codice: 

```
Quadrato quadrato = new Quadrato(5);
Rettangolo rettangolo = new Rettangolo(5,6);
```

Suggerimento: usate l’ereditarietà
